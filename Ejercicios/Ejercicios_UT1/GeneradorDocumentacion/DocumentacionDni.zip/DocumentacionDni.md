﻿<div class="header">

# Class Dni

</div>

<div class="inheritance" title="Inheritance Tree">

<a
href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html"
class="external-link"
title="class or interface in java.lang">java.lang.Object</a>

<div class="inheritance">

dni.Dni

</div>

</div>

<div id="class-description" class="section class-description">

------------------------------------------------------------------------

<div class="horizontal-scroll">

<div class="type-signature">

<span class="modifiers">public class
</span><span class="element-name type-name-label">Dni</span>
<span class="extends-implements">extends <a
href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html"
class="external-link" title="class or interface in java.lang">Object</a></span>

</div>

<div class="block">

Representa un Documento Nacional de Identidad (DNI) español.

Un DNI está formado por un número de hasta 8 cifras y una letra de
control. La letra se calcula a partir del resto de dividir el número
entre 23, y se busca en la cadena `"TRWAGMYFPDXBNJZSQVHLCKE"`.

La clase comprueba en el constructor que el número y la letra son
válidos, de modo que no se puede crear un objeto `Dni` con datos
incorrectos.

</div>

See Also:  
- `esLetraValida(int, char)`

</div>

</div>

<div class="section summary">

- <div id="constructor-summary" class="section constructor-summary">

  ## Constructor Summary

  <div class="caption">

  Constructors

  </div>

  <div class="summary-table two-column-summary">

  <div class="table-header col-first">

  Constructor

  </div>

  <div class="table-header col-last">

  Description

  </div>

  <div class="col-constructor-name even-row-color">

  <a href="#%3Cinit%3E(int,char)"
  class="member-name-link"><code>Dni</code></a>`(int numero, char letra)`

  </div>

  <div class="col-last even-row-color">

  <div class="block">

  Crea un DNI comprobando antes que el número y la letra son válidos.

  </div>

  </div>

  </div>

  </div>

- <div id="method-summary" class="section method-summary">

  ## Method Summary

  <div id="method-summary-table">

  <div class="table-tabs" role="tablist" aria-orientation="horizontal">

  All Methods
  Instance Methods
  Concrete Methods

  </div>

  <div id="method-summary-table.tabpanel" role="tabpanel"
  aria-labelledby="method-summary-table-tab0">

  <div class="summary-table three-column-summary">

  <div class="table-header col-first">

  Modifier and Type

  </div>

  <div class="table-header col-second">

  Method

  </div>

  <div class="table-header col-last">

  Description

  </div>

  <div class="col-first even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  `char`

  </div>

  <div class="col-second even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <a href="#getLetra()" class="member-name-link"><code>getLetra</code></a>`()`

  </div>

  <div class="col-last even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <div class="block">

  Devuelve la letra del DNI.

  </div>

  </div>

  <div class="col-first odd-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  `int`

  </div>

  <div class="col-second odd-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <a href="#getNumero()"
  class="member-name-link"><code>getNumero</code></a>`()`

  </div>

  <div class="col-last odd-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <div class="block">

  Devuelve el número del DNI.

  </div>

  </div>

  <div class="col-first even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  `void`

  </div>

  <div class="col-second even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <a href="#setLetra(char)"
  class="member-name-link"><code>setLetra</code></a>`(char letra)`

  </div>

  <div class="col-last even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <div class="block">

  Cambia la letra del DNI.

  </div>

  </div>

  <div class="col-first odd-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  `void`

  </div>

  <div class="col-second odd-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <a href="#setNumero(int)"
  class="member-name-link"><code>setNumero</code></a>`(int numero)`

  </div>

  <div class="col-last odd-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <div class="block">

  Cambia el número del DNI.

  </div>

  </div>

  <div class="col-first even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/String.html"
  class="external-link"
  title="class or interface in java.lang"><code>String</code></a>

  </div>

  <div class="col-second even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <a href="#toString()" class="member-name-link"><code>toString</code></a>`()`

  </div>

  <div class="col-last even-row-color method-summary-table method-summary-table-tab2 method-summary-table-tab4">

  <div class="block">

  Devuelve el DNI con el formato `00000000-L`: el número con 8 cifras
  (se rellena con ceros a la izquierda), un guion y la letra.

  </div>

  </div>

  </div>

  </div>

  </div>

  <div class="inherited-list">

  ### Methods inherited from class java.lang.<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html"
  class="external-link" title="class or interface in java.lang">Object</a>

  <a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#clone()"
  class="external-link"
  title="class or interface in java.lang"><code>clone</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#equals(java.lang.Object)"
  class="external-link"
  title="class or interface in java.lang"><code>equals</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#finalize()"
  class="external-link"
  title="class or interface in java.lang"><code>finalize</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#getClass()"
  class="external-link"
  title="class or interface in java.lang"><code>getClass</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#hashCode()"
  class="external-link"
  title="class or interface in java.lang"><code>hashCode</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#notify()"
  class="external-link"
  title="class or interface in java.lang"><code>notify</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#notifyAll()"
  class="external-link"
  title="class or interface in java.lang"><code>notifyAll</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#wait()"
  class="external-link"
  title="class or interface in java.lang"><code>wait</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#wait(long)"
  class="external-link"
  title="class or interface in java.lang"><code>wait</code></a>`, `<a
  href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#wait(long,int)"
  class="external-link"
  title="class or interface in java.lang"><code>wait</code></a>

  </div>

  </div>

</div>

<div class="section details">

- <div id="constructor-detail" class="section constructor-details">

  ## Constructor Details

  - <div id="&lt;init&gt;(int,char)" class="section detail">

    ### Dni

    <div class="horizontal-scroll">

    <div class="member-signature">

    <span class="modifiers">public</span> <span class="element-name">Dni</span><span class="parameters">(int numero,
    char letra)</span>

    </div>

    <div class="block">

    Crea un DNI comprobando antes que el número y la letra son válidos.

    </div>

    Parameters:  
    `numero` - número del DNI (mayor que 0 y como máximo 8 cifras)

    `letra` - letra de control correspondiente al número (se admite en
    mayúscula o minúscula)

    Throws:  
    <a
    href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/IllegalArgumentException.html"
    class="external-link"
    title="class or interface in java.lang"><code>IllegalArgumentException</code></a> -
    si el número no es válido o si la letra no corresponde al número

    </div>

    </div>

  </div>

- <div id="method-detail" class="section method-details">

  ## Method Details

  - <div id="getNumero()" class="section detail">

    ### getNumero

    <div class="horizontal-scroll">

    <div class="member-signature">

    <span class="modifiers">public</span> <span class="return-type">int</span> <span class="element-name">getNumero</span>()

    </div>

    <div class="block">

    Devuelve el número del DNI.

    </div>

    Returns:  
    número del DNI sin la letra

    </div>

    </div>

  - <div id="setNumero(int)" class="section detail">

    ### setNumero

    <div class="horizontal-scroll">

    <div class="member-signature">

    <span class="modifiers">public</span> <span class="return-type">void</span> <span class="element-name">setNumero</span><span class="parameters">(int numero)</span>

    </div>

    <div class="block">

    Cambia el número del DNI.
    **Nota:** este método no vuelve a validar el número ni la letra.

    </div>

    Parameters:  
    `numero` - nuevo número del DNI

    </div>

    </div>

  - <div id="getLetra()" class="section detail">

    ### getLetra

    <div class="horizontal-scroll">

    <div class="member-signature">

    <span class="modifiers">public</span> <span class="return-type">char</span> <span class="element-name">getLetra</span>()

    </div>

    <div class="block">

    Devuelve la letra del DNI.

    </div>

    Returns:  
    letra de control del DNI

    </div>

    </div>

  - <div id="setLetra(char)" class="section detail">

    ### setLetra

    <div class="horizontal-scroll">

    <div class="member-signature">

    <span class="modifiers">public</span> <span class="return-type">void</span> <span class="element-name">setLetra</span><span class="parameters">(char letra)</span>

    </div>

    <div class="block">

    Cambia la letra del DNI.
    **Nota:** este método no comprueba que la letra corresponda al
    número.

    </div>

    Parameters:  
    `letra` - nueva letra del DNI

    </div>

    </div>

  - <div id="toString()" class="section detail">

    ### toString

    <div class="horizontal-scroll">

    <div class="member-signature">

    <span class="modifiers">public</span> <span class="return-type"><a
    href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/String.html"
    class="external-link" title="class or interface in java.lang">String</a></span> <span class="element-name">toString</span>()

    </div>

    <div class="block">

    Devuelve el DNI con el formato `00000000-L`: el número con 8 cifras
    (se rellena con ceros a la izquierda), un guion y la letra.

    </div>

    Overrides:  
    <a
    href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html#toString()"
    class="external-link"
    title="class or interface in java.lang"><code>toString</code></a> in
    class <a
    href="https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Object.html"
    class="external-link"
    title="class or interface in java.lang"><code>Object</code></a>

    Returns:  
    el DNI formateado, por ejemplo `"01234567-L"`

    </div>

    </div>

  </div>

</div>